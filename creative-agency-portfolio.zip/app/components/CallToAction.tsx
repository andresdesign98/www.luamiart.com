"use client"

import { motion } from "framer-motion"

export default function CallToAction() {
  return (
    <section className="py-16 px-6 text-center">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">¡Únete a LUAMIART!</h2>
          <p className="text-lg text-gray-300 mb-8">Empieza a compartir y monetizar tu arte hoy mismo.</p>
          <a href="mailto:info@luamiart.com" className="luamiart-button inline-block">
            Contáctanos
          </a>
        </motion.div>
      </div>
    </section>
  )
}
