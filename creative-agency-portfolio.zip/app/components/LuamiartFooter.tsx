export default function LuamiartFooter() {
  return (
    <footer className="py-8 px-6 text-center text-gray-400 text-sm">
      <p>© 2025 LUAMIART - Todos los derechos reservados · info@luamiart.com</p>
    </footer>
  )
}
