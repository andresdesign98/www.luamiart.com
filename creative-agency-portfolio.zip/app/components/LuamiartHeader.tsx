"use client"

import { motion } from "framer-motion"

export default function LuamiartHeader() {
  return (
    <header className="bg-[#1e1e1e] py-16 px-4 text-center">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
        <h1 className="text-4xl md:text-6xl font-bold mb-2">LUAMIART</h1>
        <p className="text-xl text-gray-300">La red social exclusiva para creadores visuales</p>
      </motion.div>
    </header>
  )
}
