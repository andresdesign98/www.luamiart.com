"use client"

import { motion } from "framer-motion"

export default function Problem() {
  return (
    <section className="py-16 px-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">El Problema</h2>
          <p className="text-lg text-gray-300">
            Las redes sociales actuales limitan la visibilidad de los creadores visuales. Los algoritmos ocultos y la
            falta de monetización directa dificultan el crecimiento de los artistas.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
