"use client"

import { motion } from "framer-motion"
import { Palette, DollarSign, Users } from "lucide-react"

const features = [
  {
    title: "Monetización Directa",
    description: "Gana dinero por tu contenido sin intermediarios ni algoritmos opacos.",
    icon: <DollarSign className="w-10 h-10 text-luamiart mb-4" />,
  },
  {
    title: "Diseñada para Visuales",
    description: "Una plataforma pensada 100% para artistas, ilustradores, tatuadores y creadores digitales.",
    icon: <Palette className="w-10 h-10 text-luamiart mb-4" />,
  },
  {
    title: "Comunidad Creativa",
    description: "Conecta con artistas reales, haz colaboraciones y crece en comunidad.",
    icon: <Users className="w-10 h-10 text-luamiart mb-4" />,
  },
]

export default function Solution() {
  return (
    <section className="py-16 px-6 bg-[#0a0a0a]">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="section-title">Nuestra Solución</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="bg-[#2a2a2a] p-6 rounded-xl"
            >
              {feature.icon}
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-300">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
