import "./globals.css"
import { Montserrat } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import type React from "react"

// Properly configure the Montserrat font with all needed weights
const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-montserrat",
})

export const metadata = {
  title: "LUAMIART - Crea, Conecta y Monetiza",
  description: "La red social exclusiva para creadores visuales",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={`${montserrat.className} min-h-screen bg-background text-foreground`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
          <main>{children}</main>
        </ThemeProvider>
      </body>
    </html>
  )
}
