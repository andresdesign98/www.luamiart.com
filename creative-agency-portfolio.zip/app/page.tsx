import LuamiartHeader from "./components/LuamiartHeader"
import Problem from "./components/Problem"
import Solution from "./components/Solution"
import CallToAction from "./components/CallToAction"
import LuamiartFooter from "./components/LuamiartFooter"

export default function Home() {
  return (
    <>
      <LuamiartHeader />
      <Problem />
      <Solution />
      <CallToAction />
      <LuamiartFooter />
    </>
  )
}
